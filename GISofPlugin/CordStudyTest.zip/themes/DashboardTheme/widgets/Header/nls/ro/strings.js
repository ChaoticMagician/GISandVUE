define({
  "_widgetLabel": "Antet",
  "signin": "Conectare",
  "signout": "Deconectare",
  "about": "Despre",
  "signInTo": "Conectare la",
  "cantSignOutTip": "Această funcţie nu este disponibilă în modul de previzualizare."
});