define({
  "_widgetLabel": "Überschrift",
  "signin": "Anmelden",
  "signout": "Abmelden",
  "about": "Informationen",
  "signInTo": "Melden Sie sich an bei",
  "cantSignOutTip": "Diese Funktion ist im Vorschaumodus nicht verfügbar."
});