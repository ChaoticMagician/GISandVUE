define({
  "_widgetLabel": "Glava",
  "signin": "Prijava",
  "signout": "Odjava",
  "about": "Informacije",
  "signInTo": "Prijava v",
  "cantSignOutTip": "Ta funkcija ni na voljo v načinu predogleda."
});