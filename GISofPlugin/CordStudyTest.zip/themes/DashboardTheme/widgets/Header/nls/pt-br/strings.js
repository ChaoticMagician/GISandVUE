define({
  "_widgetLabel": "Cabeçalho",
  "signin": "Registrar",
  "signout": "Sair",
  "about": "Sobre",
  "signInTo": "Entrar no",
  "cantSignOutTip": "Esta função não está disponível no modo de visualização."
});