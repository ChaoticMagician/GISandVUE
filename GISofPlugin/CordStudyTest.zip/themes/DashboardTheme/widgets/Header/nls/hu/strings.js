define({
  "_widgetLabel": "Fejléc",
  "signin": "Bejelentkezés",
  "signout": "Kijelentkezés",
  "about": "További információ",
  "signInTo": "Bejelentkezés ide:",
  "cantSignOutTip": "Ez a funkció előnézeti módban nem érhető el."
});