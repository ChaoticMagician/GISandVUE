define({
  "_widgetLabel": "Overskrift",
  "signin": "Logg på",
  "signout": "Logg av",
  "about": "Om",
  "signInTo": "Logg inn på",
  "cantSignOutTip": "Denne funksjonen er ikke tilgjengelig i forhåndsvisningsmodus."
});