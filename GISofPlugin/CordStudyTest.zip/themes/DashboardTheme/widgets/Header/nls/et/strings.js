define({
  "_widgetLabel": "Päis",
  "signin": "Logi sisse",
  "signout": "Logi välja",
  "about": "Info",
  "signInTo": "Logi sisse",
  "cantSignOutTip": "See objekt pole eelvaaterežiimis saadaval."
});