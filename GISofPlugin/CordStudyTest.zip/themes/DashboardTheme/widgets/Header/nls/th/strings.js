define({
  "_widgetLabel": "ส่วนหัว",
  "signin": "ลงชื่อเข้าใช้",
  "signout": "ออกจากระบบ",
  "about": "เกี่ยวกับ",
  "signInTo": "เข้าสู่ระบบ",
  "cantSignOutTip": "ฟังก์ชันนี้ไม่มีในโหมดแสดงตัวอย่าง"
});