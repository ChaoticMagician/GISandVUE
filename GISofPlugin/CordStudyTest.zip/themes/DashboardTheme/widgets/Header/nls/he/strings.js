define({
  "_widgetLabel": "כותרת עליונה",
  "signin": "התחבר",
  "signout": "התנתק",
  "about": "אודות",
  "signInTo": "התחבר אל",
  "cantSignOutTip": "פונקציה זו אינה זמינה במצב תצוגה מקדימה."
});