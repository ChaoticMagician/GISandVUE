define({
  "_widgetLabel": "رأس الصفحة",
  "signin": "تسجيل الدخول",
  "signout": "تسجيل الخروج",
  "about": "نبذة عن",
  "signInTo": "تسجيل الدخول إلى",
  "cantSignOutTip": "هذه الوظيفة غير متاحة في وضع المعاينة."
});