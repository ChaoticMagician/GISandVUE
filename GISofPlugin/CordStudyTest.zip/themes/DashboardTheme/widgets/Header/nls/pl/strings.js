define({
  "_widgetLabel": "Nagłówek",
  "signin": "Zaloguj",
  "signout": "Wyloguj",
  "about": "Informacje o",
  "signInTo": "Zaloguj się do",
  "cantSignOutTip": "Ta funkcja nie jest dostępna w trybie podglądu."
});