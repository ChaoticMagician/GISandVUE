define({
  "_widgetLabel": "Antraštė",
  "signin": "Prisijunkite",
  "signout": "Atsijungti",
  "about": "Apie",
  "signInTo": "Prisijungti į",
  "cantSignOutTip": "Ši funkcija veikiant peržiūros režimu negalima."
});