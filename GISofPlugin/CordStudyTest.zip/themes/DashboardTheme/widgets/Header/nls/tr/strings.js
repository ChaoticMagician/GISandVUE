define({
  "_widgetLabel": "Başlık",
  "signin": "Oturum aç",
  "signout": "Oturumu kapat",
  "about": "Yaklaşık",
  "signInTo": "Şurada oturum aç:",
  "cantSignOutTip": "Bu işlev ön izleme modunda kullanılmaz."
});