define({
  "_themeLabel": "Thème du tableau de bord",
  "_layout_default": "Mise en page par défaut",
  "_layout_right": "Disposition à droite"
});