define({
  "_themeLabel": "Nadzorna plošča",
  "_layout_default": "Privzeta postavitev",
  "_layout_right": "Desna postavitev"
});