define({
  "_widgetLabel": "日光",
  "dragSunSliderText": "拖動滑稈更改時間。",
  "directShadow": "直接陰影(陽光投射)",
  "diffuseShadow": "散射陰影(環境遮擋)",
  "shadowing": "陰影"
});