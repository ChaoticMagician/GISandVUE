define({
  "_widgetLabel": "Tageslicht",
  "dragSunSliderText": "Ziehen Sie den Schieberegler, um die Uhrzeit zu ändern.",
  "directShadow": "Direkter Schatten (durch Sonnenlicht)",
  "diffuseShadow": "Diffuse Schatten (Umgebungsverdeckung)",
  "shadowing": "Schatten"
});