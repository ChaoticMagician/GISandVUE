define({
  "_widgetLabel": "Päivänvalo",
  "dragSunSliderText": "Muuta kellonaikaa vetämällä liukusäädintä.",
  "directShadow": "Suora varjo (auringonvalosta)",
  "diffuseShadow": "Epäselvät varjot (ympäristön sulkeminen)",
  "shadowing": "Varjostus"
});