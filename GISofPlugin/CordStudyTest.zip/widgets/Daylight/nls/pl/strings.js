define({
  "_widgetLabel": "Światło dzienne",
  "dragSunSliderText": "Przeciągnij suwak, aby zmienić porę dnia.",
  "directShadow": "Wyraźne cienie (rzucane przy świetle słonecznym)",
  "diffuseShadow": "Rozproszone cienie (okluzja otoczenia)",
  "shadowing": "Cieniowanie"
});