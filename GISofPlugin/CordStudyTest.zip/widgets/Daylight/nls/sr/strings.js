define({
  "_widgetLabel": "Dnevna svetlost",
  "dragSunSliderText": "Prevucite slajder da biste promenili vreme dana.",
  "directShadow": "Direktna senka (bačena sunčevom svetlošću)",
  "diffuseShadow": "Difuzne senke (ambijentalna okluzija)",
  "shadowing": "Senčenje"
});