define({
  "_widgetLabel": "日光",
  "dragSunSliderText": "スライダーをドラッグして、時刻を変更します。",
  "directShadow": "直接的な影 (日差し)",
  "diffuseShadow": "影の拡散 (環境遮蔽)",
  "shadowing": "影"
});