define({
  "_widgetLabel": "Llum del dia",
  "dragSunSliderText": "Arrossegueu el control lliscant per canviar l'hora del dia.",
  "directShadow": "Ombra directa (projectada per la llum solar)",
  "diffuseShadow": "Ombres difuses (oclusió ambiental)",
  "shadowing": "Ombrejat"
});