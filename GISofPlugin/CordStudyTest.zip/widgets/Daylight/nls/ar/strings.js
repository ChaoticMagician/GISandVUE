define({
  "_widgetLabel": "ضوء النهار",
  "dragSunSliderText": "اسحب المنزلق لتغيير وقت اليوم.",
  "directShadow": "الظل المباشر (بواسطة ضوء الشمس)",
  "diffuseShadow": "انتشار الظلال (تقنية الضوء والظلال)",
  "shadowing": "التظليل"
});