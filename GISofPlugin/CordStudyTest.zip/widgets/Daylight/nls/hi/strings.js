define({
  "_widgetLabel": "दिन का प्रकाश",
  "dragSunSliderText": "दिन का समय बदलने के लिए स्लाइडर को ड्रैग करें।",
  "directShadow": "सीधी परछाई (सूर्य प्रकाश से बनी)",
  "diffuseShadow": "परछाई का प्रसार (परिवेशी बाधा)",
  "shadowing": "ग्रहण"
});