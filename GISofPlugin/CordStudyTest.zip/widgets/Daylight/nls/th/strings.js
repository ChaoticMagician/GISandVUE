define({
  "_widgetLabel": "แสงกลางวัน",
  "dragSunSliderText": "ลากตัวเลื่อนเพื่อเปลี่ยนช่วงเวลาของวัน",
  "directShadow": "เงาตรง (รับจากแสงแดด)",
  "diffuseShadow": "การกระจายแสง (บิดโดยรอบ)",
  "shadowing": "เงา"
});