define({
  "defaultTimeZone": "डिफ़ॉल्ट समय क्षेत्र सेट करें:"
});