define({
  "defaultTimeZone": "Selezionare il fuso orario predefinito:"
});