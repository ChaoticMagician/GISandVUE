define({
  "defaultTimeZone": "تعيين المنطقة الزمنية الافتراضية:"
});