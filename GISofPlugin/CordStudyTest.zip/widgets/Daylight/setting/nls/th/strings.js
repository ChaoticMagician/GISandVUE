define({
  "defaultTimeZone": "ตั้งค่าโซนเวลาเริ่มต้น:"
});