define({
  "defaultTimeZone": "Atur zona waktu default:"
});