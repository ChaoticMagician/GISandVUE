define({
  "defaultTimeZone": "Definir o fuso horário padrão:"
});