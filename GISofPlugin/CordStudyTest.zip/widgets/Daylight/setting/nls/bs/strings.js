define({
  "defaultTimeZone": "Postavite zadanu vremensku zonu:"
});