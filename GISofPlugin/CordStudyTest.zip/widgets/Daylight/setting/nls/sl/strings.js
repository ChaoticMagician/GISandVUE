define({
  "defaultTimeZone": "Nastavite privzeti časovni pas:"
});