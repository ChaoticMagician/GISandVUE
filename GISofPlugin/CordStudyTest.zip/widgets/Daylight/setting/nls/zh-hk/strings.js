define({
  "defaultTimeZone": "設定預設時區:"
});