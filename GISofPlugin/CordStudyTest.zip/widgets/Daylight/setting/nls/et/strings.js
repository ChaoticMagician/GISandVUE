define({
  "defaultTimeZone": "Määra vaikeajavöönd:"
});