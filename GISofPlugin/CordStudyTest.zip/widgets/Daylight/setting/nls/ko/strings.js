define({
  "defaultTimeZone": "기본 시간대 설정:"
});