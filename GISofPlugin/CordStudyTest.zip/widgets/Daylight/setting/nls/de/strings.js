define({
  "defaultTimeZone": "Standardzeitzone festlegen:"
});