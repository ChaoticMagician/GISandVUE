define({
  "defaultTimeZone": "Configurar o fuso horário padrão:"
});