define({
  "defaultTimeZone": "Defineix la zona horària per defecte:"
});