define({
  "defaultTimeZone": "Définir le fuseau horaire par défaut :"
});