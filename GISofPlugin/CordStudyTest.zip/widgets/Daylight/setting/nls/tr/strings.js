define({
  "defaultTimeZone": "Varsayılan zaman dilimini ayarlayın:"
});