define({
  "defaultTimeZone": "Ustaw domyślną strefę czasową:"
});