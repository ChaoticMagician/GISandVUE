define({
  "defaultTimeZone": "Angiv standardtidszone:"
});