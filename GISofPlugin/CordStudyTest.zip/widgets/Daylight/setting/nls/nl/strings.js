define({
  "defaultTimeZone": "Stel de standaard tijdzone in:"
});