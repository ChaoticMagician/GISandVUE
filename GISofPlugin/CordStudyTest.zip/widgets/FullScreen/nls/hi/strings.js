define({
  "_widgetLabel": "पूर्ण स्क्रीन"
});