define({
  "_widgetLabel": "Teljes képernyő"
});