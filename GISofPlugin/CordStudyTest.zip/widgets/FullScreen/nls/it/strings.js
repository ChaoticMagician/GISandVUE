define({
  "_widgetLabel": "Schermo Intero"
});