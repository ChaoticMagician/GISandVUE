define({
  "_widgetLabel": "מסך מלא"
});