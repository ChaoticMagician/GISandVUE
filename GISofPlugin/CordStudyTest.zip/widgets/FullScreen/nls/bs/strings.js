define({
  "_widgetLabel": "Puni zaslon"
});