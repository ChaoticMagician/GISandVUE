define({
  "_widgetLabel": "Plein écran"
});